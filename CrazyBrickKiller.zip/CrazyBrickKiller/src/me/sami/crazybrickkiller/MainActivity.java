package me.sami.crazybrickkiller;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class MainActivity extends Activity {

	private Button playButton, exitButton;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_main);
		//setContentView(new MainGameCanvas(this)); 
		
		playButton = (Button) findViewById(R.id.buttonPlay);
		exitButton = (Button) findViewById(R.id.buttonExit);
		
		playButton.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch(event.getAction()) {
					case MotionEvent.ACTION_DOWN:
						playButton.getBackground().setAlpha(0);
						break;
					case MotionEvent.ACTION_UP:
						playButton.getBackground().setAlpha(255);
						Intent intent = new Intent(MainActivity.this, StartGameActivity.class);
						startActivity(intent);
						break;
				}
				return true;
			}
		});
		
		exitButton.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch(event.getAction()) {
					case MotionEvent.ACTION_DOWN:
						playButton.getBackground().setAlpha(0);
						break;
					case MotionEvent.ACTION_UP:
						playButton.getBackground().setAlpha(255);
						finish();
						System.exit(0);
						break;
				}
				return true;
			}
		});
	}
	
	/*@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		finish();
		System.exit(0);
	}*/

}
