package me.sami.crazybrickkiller;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;

public class Level{
	
	private final int xCount=110;

	public Level(Context context) {
		// TODO Auto-generated constructor stub
	}
	
	public Brick[] BrickColorBack(Context context, Brick brOne[]) {
		brOne[0] = new Brick(context, Color.BLUE);
		brOne[1] = new Brick(context, Color.BLUE);
		brOne[2] = new Brick(context, Color.BLUE);
		brOne[3] = new Brick(context, Color.BLUE);
		brOne[4] = new Brick(context, Color.BLUE);
		brOne[5] = new Brick(context, Color.CYAN);
		brOne[6] = new Brick(context, Color.CYAN);
		brOne[7] = new Brick(context, Color.CYAN);
		brOne[8] = new Brick(context, Color.CYAN);
		brOne[9] = new Brick(context, Color.MAGENTA);
		brOne[10] = new Brick(context, Color.MAGENTA);
		brOne[11] = new Brick(context, Color.MAGENTA);
		brOne[12] = new Brick(context, Color.BLUE);
		brOne[13] = new Brick(context, Color.BLUE);
		brOne[14] = new Brick(context, Color.BLUE);
		brOne[15] = new Brick(context, Color.BLUE);
		brOne[16] = new Brick(context, Color.BLUE);
		brOne[17] = new Brick(context, Color.CYAN);
		brOne[18] = new Brick(context, Color.CYAN);
		brOne[19] = new Brick(context, Color.CYAN);
		brOne[20] = new Brick(context, Color.CYAN);
		brOne[21] = new Brick(context, Color.MAGENTA);
		brOne[22] = new Brick(context, Color.MAGENTA);
		brOne[23] = new Brick(context, Color.MAGENTA);
		
		return brOne;
	}
	
	public Brick[] AllFlagTrue(Brick brOne[]) {
		brOne[0].SetFlagTrue();
		brOne[1].SetFlagTrue();
		brOne[2].SetFlagTrue();
		brOne[3].SetFlagTrue();
		brOne[4].SetFlagTrue();
		brOne[5].SetFlagTrue();
		brOne[6].SetFlagTrue();
		brOne[7].SetFlagTrue();
		brOne[8].SetFlagTrue();
		brOne[9].SetFlagTrue();
		brOne[10].SetFlagTrue();
		brOne[11].SetFlagTrue();
		brOne[12].SetFlagTrue();
		brOne[13].SetFlagTrue();
		brOne[14].SetFlagTrue();
		brOne[15].SetFlagTrue();
		brOne[16].SetFlagTrue();
		brOne[17].SetFlagTrue();
		brOne[18].SetFlagTrue();
		brOne[19].SetFlagTrue();
		brOne[20].SetFlagTrue();
		brOne[21].SetFlagTrue();
		brOne[22].SetFlagTrue();
		brOne[23].SetFlagTrue();
		
		return brOne;
	}

	// Level 1
	public void InitializeAllLevelOne(Canvas canvas, Brick brOne[]) {
		
		//Left Bricks
		brOne[0].Initialize(canvas, 50, 50);
		brOne[1].Initialize(canvas, 50+(xCount*1), 50);
		brOne[2].Initialize(canvas, 50+(xCount*2), 50);
		brOne[3].Initialize(canvas, 50+(xCount*3), 50);
		brOne[4].Initialize(canvas, 50+(xCount*4), 50);
				
		brOne[5].Initialize(canvas, 110, 110);
		brOne[6].Initialize(canvas, 110+(xCount*1), 110);
		brOne[7].Initialize(canvas, 110+(xCount*2), 110);
		brOne[8].Initialize(canvas, 110+(xCount*3), 110);
		
		brOne[9].Initialize(canvas, 170, 170);
		brOne[10].Initialize(canvas, 170+(xCount*1), 170);
		brOne[11].Initialize(canvas, 170+(xCount*2), 170);
				
		//Right bricks
		brOne[12].Initialize(canvas, 140+(xCount*5), 50);
		brOne[13].Initialize(canvas, 140+(xCount*6), 50);
		brOne[14].Initialize(canvas, 140+(xCount*7), 50);
		brOne[15].Initialize(canvas, 140+(xCount*8), 50);
		brOne[16].Initialize(canvas, 140+(xCount*9), 50);
						
		brOne[17].Initialize(canvas, 200+(xCount*5), 110);
		brOne[18].Initialize(canvas, 200+(xCount*6), 110);
		brOne[19].Initialize(canvas, 200+(xCount*7), 110);
		brOne[20].Initialize(canvas, 200+(xCount*8), 110);
						
		brOne[21].Initialize(canvas, 260+(xCount*5), 170);
		brOne[22].Initialize(canvas, 260+(xCount*6), 170);
		brOne[23].Initialize(canvas, 260+(xCount*7), 170);
	}
	
	//Level 2
	public void InitializeAllLevelTwo(Canvas canvas, Brick brOne[]) {
		
		//Left Bricks
		brOne[5].Initialize(canvas, 50, 50);
		brOne[6].Initialize(canvas, 50, 110);
		brOne[7].Initialize(canvas, 50, 170);
		brOne[8].Initialize(canvas, 50, 230);
		
		//Right Bricks
		brOne[17].Initialize(canvas, 260+(xCount*8), 50);
		brOne[18].Initialize(canvas, 260+(xCount*8), 110);
		brOne[19].Initialize(canvas, 260+(xCount*8), 170);
		brOne[20].Initialize(canvas, 260+(xCount*8), 230);
		
		//Brick Middle
		//First Layer
		brOne[0].Initialize(canvas, canvas.getWidth()/2, 50);
		brOne[1].Initialize(canvas, canvas.getWidth()/2+(xCount*1), 50);
		brOne[2].Initialize(canvas, canvas.getWidth()/2+(xCount*2), 50);
		brOne[3].Initialize(canvas, canvas.getWidth()/2-(xCount*1), 50);
		brOne[4].Initialize(canvas, canvas.getWidth()/2-(xCount*2), 50);
				
		//2nd Layer
		brOne[9].Initialize(canvas, canvas.getWidth()/2-55, 110);
		brOne[10].Initialize(canvas, canvas.getWidth()/2-55-(xCount*1), 110);
		brOne[11].Initialize(canvas, canvas.getWidth()/2-55+(xCount*1), 110);
		brOne[21].Initialize(canvas, canvas.getWidth()/2-55+(xCount*2), 110);
		
		//Third Layer
		brOne[12].Initialize(canvas, canvas.getWidth()/2-(xCount*1), 170);
		brOne[22].Initialize(canvas, canvas.getWidth()/2, 170);
		brOne[13].Initialize(canvas, canvas.getWidth()/2+(xCount*1), 170);
		
		//Fourth Layer
		brOne[14].Initialize(canvas, canvas.getWidth()/2-55, 230);
		brOne[15].Initialize(canvas, canvas.getWidth()/2-55+(xCount*1), 230);
		
		//Fifth Layer
		brOne[23].Initialize(canvas, canvas.getWidth()/2, 290);
	}
}
