package me.sami.crazybrickkiller;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Paint.Style;
import android.view.View;

public class SpecialBricks extends View {

	private Paint p;
	private int X, Y;
	private boolean presenceFlag = true;
	
	public SpecialBricks(Context context,  int color) {
		super(context);
		// TODO Auto-generated constructor stub
		p = new Paint();
		p.setColor(color);
		p.setStyle(Style.FILL);
		p.setStrokeWidth(10);
	}
	
	public void Initialize(Canvas canvas, int x, int y) {
		X = x;
		Y = y;
		Rect rect = new Rect();
		rect.set(x, y, x+100, y+50);
		canvas.drawRect(rect, p);
	}
	
	//Erase a brick
		public void Erase(int color) {
			p.setColor(color);
		}
			
		public float getX() {
			return X;
		}
		
		public float getY() {
			return Y;
		}
		
		public boolean GetFlag() {
			return presenceFlag;
		}
		
		public void SetFlagTrue() {
			presenceFlag = true;
		}
		
		// Erase Location of Brick
		public void NoBrick() {
			presenceFlag = false;
		}

}
