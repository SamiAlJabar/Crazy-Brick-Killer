package me.sami.crazybrickkiller;

import java.util.Random;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;

public class MainGameCanvas extends View {
	
	private final Random rand = new Random();
	int random;
	
	int xCount = 110;	//For Brick Postion Counts
	Paint textP;
	int countDown=3;
	int playerHealth=2;
	int ballSpeedX, ballSpeedY;
	
	private Brick[] brOne = new Brick[24];
	private Player player;
	private Ball ball;
	
	private int xBall, yBall;
	private int xPlayer, yPlayer, playerSize;
	private int xBrickOne, yBrickOne, xBrickTwo, yBrickTwo, xBrickThree, yBrickThree, xBrickFour, yBrickFour, xBrickFive, yBrickFive, xBrickSix, yBrickSix;
	private boolean xBallFlag=true, yBallFlag=false;
	private boolean firstTime=true;
	
	private boolean touchFlag = false;
	private int screenX;
	
	private int scoreCount;
	private int levelCount;
	
	private Level level;
	
	//Special Brick
	private SpecialBricks[] specialBrick = new SpecialBricks[4];
	int specialBrickSpeedX, specialBrickSpeedY=0;
	int specialFlag = 0;
	
	Vibrator vb;
	
	/*float x=0,y=0;
	int r;
	boolean firstTime=true;
	boolean xFlag=true;
	boolean yFlag=true;*/
	
	public MainGameCanvas(Context context) {
		super(context);
		
		
		//All bricks
		brOne[0] = new Brick(context, Color.BLUE);
		brOne[1] = new Brick(context, Color.BLUE);
		brOne[2] = new Brick(context, Color.BLUE);
		brOne[3] = new Brick(context, Color.BLUE);
		brOne[4] = new Brick(context, Color.BLUE);
		brOne[5] = new Brick(context, Color.CYAN);
		brOne[6] = new Brick(context, Color.CYAN);
		brOne[7] = new Brick(context, Color.CYAN);
		brOne[8] = new Brick(context, Color.CYAN);
		brOne[9] = new Brick(context, Color.MAGENTA);
		brOne[10] = new Brick(context, Color.MAGENTA);
		brOne[11] = new Brick(context, Color.MAGENTA);
		brOne[12] = new Brick(context, Color.BLUE);
		brOne[13] = new Brick(context, Color.BLUE);
		brOne[14] = new Brick(context, Color.BLUE);
		brOne[15] = new Brick(context, Color.BLUE);
		brOne[16] = new Brick(context, Color.BLUE);
		brOne[17] = new Brick(context, Color.CYAN);
		brOne[18] = new Brick(context, Color.CYAN);
		brOne[19] = new Brick(context, Color.CYAN);
		brOne[20] = new Brick(context, Color.CYAN);
		brOne[21] = new Brick(context, Color.MAGENTA);
		brOne[22] = new Brick(context, Color.MAGENTA);
		brOne[23] = new Brick(context, Color.MAGENTA);
		
		specialBrick[0] = new SpecialBricks(context, Color.RED);
		specialBrick[1] = new SpecialBricks(context, Color.RED);
		specialBrick[2] = new SpecialBricks(context, Color.GREEN);
		specialBrick[3] = new SpecialBricks(context, Color.GREEN);
		
		vb = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
		
		
		//Player
		player = new Player(context, Color.WHITE);
		
		//Ball
		ball = new Ball(context, Color.RED);
		
		scoreCount=0;
		levelCount=1;
		
		level = new Level(context);
		
		textP = new Paint();
		textP.setColor(Color.WHITE); 
		textP.setTextSize(50); 
	}
	
	// OnDraw
	protected void onDraw(final Canvas canvas) {

		
		canvas.drawRGB(0, 0, 0);
		if(firstTime)
		{
			playerHealth = 2;
			firstTime=false;
			yBallFlag = false;
			xBall=canvas.getWidth() / 2;
			yBall=canvas.getHeight();
			
			xPlayer = (canvas.getWidth()/2)-125;
			yPlayer = canvas.getHeight()-50;
			playerSize = 250;
			
			ballSpeedX = 13;
			ballSpeedY = 7;
			
			specialFlag = 0;
		}
		
		Drawable d = getResources().getDrawable(R.drawable.background);
		d.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
		d.draw(canvas);
		
		// Check end of level
		if(scoreCount == 24 && levelCount == 1) {

			levelCount++;
			scoreCount = 0;
			level.AllFlagTrue(brOne);
			level.BrickColorBack(getContext(), brOne);
			firstTime = true;
			xBall=canvas.getWidth() / 2;
			yBall=canvas.getHeight();
			
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if(scoreCount == 23 && levelCount == 2) {
			levelCount++;
		}
		
		//Level Change
		if(levelCount == 1) {
			level.InitializeAllLevelOne(canvas, brOne);textP.setColor(Color.YELLOW);
			textP.setColor(Color.YELLOW); 
			textP.setTextSize(50);
			canvas.drawText("Level " +levelCount, canvas.getWidth()/2-75, 50, textP);
		}
		else if (levelCount == 2) {
			level.InitializeAllLevelTwo(canvas, brOne);
			textP.setColor(Color.YELLOW); 
			textP.setTextSize(50);
			canvas.drawText("Level " +levelCount, canvas.getWidth()/2-75, 50, textP);
		} else {
			ballSpeedX = 0;
			ballSpeedY = 0;
			xPlayer = -1000;
			xBall = -1000;
			yBall = 0;
			textP.setColor(Color.YELLOW); 
			textP.setTextSize(100);
			canvas.drawText("You Win", canvas.getWidth()/2-170, canvas.getHeight()/2+50, textP);
		}
		
		//Player
		if(playerHealth == 2) {
			ball.Initialize(canvas, xBall, yBall, 20, Color.YELLOW);
			player.Initialize(canvas, xPlayer, yPlayer, Color.WHITE, playerSize); //Player xlength = 250, yLength = 50
		}
		else if(playerHealth == 1) {
			ball.Initialize(canvas, xBall, yBall, 20, Color.RED);
			player.Initialize(canvas, xPlayer, yPlayer, Color.WHITE, playerSize); //Player xlength = 250, yLength = 50
		} else {
			ballSpeedX = 0;
			ballSpeedY = 0;
			xPlayer = 0;
			textP.setColor(Color.YELLOW); 
			textP.setTextSize(100);
			canvas.drawText("Game Over", canvas.getWidth()/2-250, canvas.getHeight()/2+50, textP);
		}
				
				
		//Ball		
		
		// Screen Tap checking x position on screen
		this.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				screenX = (int)event.getX();
				switch(event.getAction()) {
					case MotionEvent.ACTION_DOWN:
						touchFlag = true;
						break;
					case MotionEvent.ACTION_UP:
						touchFlag = false;
						break;
				}
				return true;
			}
		});
		
		
		
		
		Collision(canvas);
		
		// Player Movement According to Touch
		if(touchFlag) {
			if(screenX > canvas.getWidth()/2) {
				xPlayer += 15;
				if(xPlayer >= canvas.getWidth()-playerSize)
					xPlayer = canvas.getWidth()-playerSize;
			} else {
				xPlayer -= 15;
				if(xPlayer <= 0)
					xPlayer = 0;
			}
		} else {
			xPlayer = xPlayer;
		}
		
		invalidate();
	}
	
	protected void Collision(Canvas canvas){
		xBall++;
		
		// Collision between Player and Ball
		if(yBall-20 > canvas.getHeight()-100 && (xBall-20 >= player.getX() && xBall-20 <= player.getX()+playerSize)) {
			yBallFlag = true;
			if(xBall-20 >= player.getX() && xBall-20 <= player.getX()+(playerSize/5))
				xBallFlag = true;
			else if(xBall-20 >= player.getX()+((playerSize/5)*4) && xBall-20 <= player.getX()+playerSize)
				xBallFlag = false;
			
		}
		
		// Collision between Bricks and Ball
		//Ball 1
		if((yBall-20 > brOne[0].getY()-80 && yBall-20 < brOne[0].getY()+60) && (xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100)  && brOne[0].GetFlag() == true) {
		
			if((xBall-20 > brOne[0].getX()+87 && xBall-20 < brOne[0].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[0].Erase(Color.TRANSPARENT);
			brOne[0].NoBrick();
			scoreCount++;
			
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 2
		if((yBall-20 > brOne[1].getY()-80 && yBall-20 < brOne[1].getY()+60) && (xBall-20 > brOne[1].getX()-50 && xBall-20 < brOne[1].getX()+100) && brOne[1].GetFlag() == true) {
			
			if((xBall-20 > brOne[1].getX()+87 && xBall-20 < brOne[1].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[1].getX()-50 && xBall-20 < brOne[1].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[1].Erase(Color.TRANSPARENT);
			brOne[1].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 3
		if((yBall-20 > brOne[2].getY()-80 && yBall-20 < brOne[2].getY()+60) && (xBall-20 > brOne[2].getX()-50 && xBall-20 < brOne[2].getX()+100)  && brOne[2].GetFlag() == true) {
			
			if((xBall-20 > brOne[2].getX()+87 && xBall-20 < brOne[2].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[2].getX()-50 && xBall-20 < brOne[2].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[2].Erase(Color.TRANSPARENT);
			brOne[2].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}		
		
		//Ball 4
		if((yBall-20 > brOne[3].getY()-80 && yBall-20 < brOne[3].getY()+60) && (xBall-20 > brOne[3].getX()-50 && xBall-20 < brOne[3].getX()+100)  && brOne[3].GetFlag() == true) {
			
			if((xBall-20 > brOne[3].getX()+87 && xBall-20 < brOne[3].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[3].getX()-50 && xBall-20 < brOne[3].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[3].Erase(Color.TRANSPARENT);
			brOne[3].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}		
		
		//Ball 5
		if((yBall-20 > brOne[4].getY()-80 && yBall-20 < brOne[4].getY()+60) && (xBall-20 > brOne[4].getX()-50 && xBall-20 < brOne[4].getX()+100)  && brOne[4].GetFlag() == true) {
			
			if((xBall-20 > brOne[4].getX()+87 && xBall-20 < brOne[4].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[4].getX()-50 && xBall-20 < brOne[4].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[4].Erase(Color.TRANSPARENT);
			brOne[4].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 6
		if((yBall-20 > brOne[5].getY()-80 && yBall-20 < brOne[5].getY()+60) && (xBall-20 > brOne[5].getX()-50 && xBall-20 < brOne[5].getX()+100)  && brOne[5].GetFlag() == true) {
			
			if((xBall-20 > brOne[5].getX()+87 && xBall-20 < brOne[5].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[5].getX()-50 && xBall-20 < brOne[5].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[5].Erase(Color.TRANSPARENT);
			brOne[5].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}		
		
		//Ball 7
		if((yBall-20 > brOne[6].getY()-80 && yBall-20 < brOne[6].getY()+60) && (xBall-20 > brOne[6].getX()-50 && xBall-20 < brOne[6].getX()+100)  && brOne[6].GetFlag() == true) {
			
			if((xBall-20 > brOne[6].getX()+87 && xBall-20 < brOne[6].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[6].getX()-50 && xBall-20 < brOne[6].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[6].Erase(Color.TRANSPARENT);
			brOne[6].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}	
		
		//Ball 8
		if((yBall-20 > brOne[7].getY()-80 && yBall-20 < brOne[7].getY()+60) && (xBall-20 > brOne[7].getX()-50 && xBall-20 < brOne[7].getX()+100)  && brOne[7].GetFlag() == true) {
			
			if((xBall-20 > brOne[7].getX()+87 && xBall-20 < brOne[7].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[7].getX()-50 && xBall-20 < brOne[7].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[7].Erase(Color.TRANSPARENT);
			brOne[7].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}	
		
		//Ball 9
		if((yBall-20 > brOne[8].getY()-80 && yBall-20 < brOne[8].getY()+60) && (xBall-20 > brOne[8].getX()-50 && xBall-20 < brOne[8].getX()+100)  && brOne[8].GetFlag() == true) {
			
			if((xBall-20 > brOne[8].getX()+87 && xBall-20 < brOne[8].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[8].getX()-50 && xBall-20 < brOne[8].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[8].Erase(Color.TRANSPARENT);
			brOne[8].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}		
		
		//Ball 10
		if((yBall-20 > brOne[9].getY()-80 && yBall-20 < brOne[9].getY()+60) && (xBall-20 > brOne[9].getX()-50 && xBall-20 < brOne[9].getX()+100) && brOne[9].GetFlag() == true) {
			
			if((xBall-20 > brOne[9].getX()+87 && xBall-20 < brOne[9].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[9].getX()-50 && xBall-20 < brOne[9].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[9].Erase(Color.TRANSPARENT);
			brOne[9].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}	
		
		//Ball 11
		if((yBall-20 > brOne[10].getY()-80 && yBall-20 < brOne[10].getY()+60) && (xBall-20 > brOne[10].getX()-50 && xBall-20 < brOne[10].getX()+100) && brOne[10].GetFlag() == true) {
			
			if((xBall-20 > brOne[10].getX()+87 && xBall-20 < brOne[10].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[10].getX()-50 && xBall-20 < brOne[10].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[10].Erase(Color.TRANSPARENT);
			brOne[10].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 12
		if((yBall-20 > brOne[11].getY()-80 && yBall-20 < brOne[11].getY()+60) && (xBall-20 > brOne[11].getX()-50 && xBall-20 < brOne[11].getX()+100) && brOne[11].GetFlag() == true) {
			
			if((xBall-20 > brOne[11].getX()+87 && xBall-20 < brOne[11].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[11].getX()-50 && xBall-20 < brOne[11].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[11].Erase(Color.TRANSPARENT);
			brOne[11].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 13
		if((yBall-20 > brOne[12].getY()-80 && yBall-20 < brOne[12].getY()+60) && (xBall-20 > brOne[12].getX()-50 && xBall-20 < brOne[12].getX()+100) && brOne[12].GetFlag() == true) {
			
			if((xBall-20 > brOne[12].getX()+87 && xBall-20 < brOne[12].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[12].getX()-50 && xBall-20 < brOne[12].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[12].Erase(Color.TRANSPARENT);
			brOne[12].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 14
		if((yBall-20 > brOne[13].getY()-80 && yBall-20 < brOne[13].getY()+60) && (xBall-20 > brOne[13].getX()-50 && xBall-20 < brOne[13].getX()+100) && brOne[13].GetFlag() == true) {
			
			if((xBall-20 > brOne[13].getX()+87 && xBall-20 < brOne[13].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[13].getX()-50 && xBall-20 < brOne[13].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[13].Erase(Color.TRANSPARENT);
			brOne[13].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 15
		if((yBall-20 > brOne[14].getY()-80 && yBall-20 < brOne[14].getY()+60) && (xBall-20 > brOne[14].getX()-50 && xBall-20 < brOne[14].getX()+100) && brOne[14].GetFlag() == true) {
			
			if((xBall-20 > brOne[14].getX()+87 && xBall-20 < brOne[14].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[14].getX()-50 && xBall-20 < brOne[14].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[14].Erase(Color.TRANSPARENT);
			brOne[14].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}	
		
		//Ball 16
		if((yBall-20 > brOne[15].getY()-80 && yBall-20 < brOne[15].getY()+60) && (xBall-20 > brOne[15].getX()-50 && xBall-20 < brOne[15].getX()+100) && brOne[15].GetFlag() == true) {
			
			if((xBall-20 > brOne[15].getX()+87 && xBall-20 < brOne[15].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[15].getX()-50 && xBall-20 < brOne[15].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[15].Erase(Color.TRANSPARENT);
			brOne[15].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 17
		if((yBall-20 > brOne[16].getY()-80 && yBall-20 < brOne[16].getY()+60) && (xBall-20 > brOne[16].getX()-50 && xBall-20 < brOne[16].getX()+100) && brOne[16].GetFlag() == true) {
			
			if((xBall-20 > brOne[16].getX()+87 && xBall-20 < brOne[16].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[16].getX()-50 && xBall-20 < brOne[16].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[16].Erase(Color.TRANSPARENT);
			brOne[16].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}		
		
		//Ball 18
		if((yBall-20 > brOne[17].getY()-80 && yBall-20 < brOne[17].getY()+60) && (xBall-20 > brOne[17].getX()-50 && xBall-20 < brOne[17].getX()+100) && brOne[17].GetFlag() == true) {
			
			if((xBall-20 > brOne[17].getX()+87 && xBall-20 < brOne[17].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[17].getX()-50 && xBall-20 < brOne[17].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[17].Erase(Color.TRANSPARENT);
			brOne[17].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}		
		
		//Ball 19
		if((yBall-20 > brOne[18].getY()-80 && yBall-20 < brOne[18].getY()+60) && (xBall-20 > brOne[18].getX()-50 && xBall-20 < brOne[18].getX()+100) && brOne[18].GetFlag() == true) {
			
			if((xBall-20 > brOne[18].getX()+87 && xBall-20 < brOne[18].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[18].getX()-50 && xBall-20 < brOne[18].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[18].Erase(Color.TRANSPARENT);
			brOne[18].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 20
		if((yBall-20 > brOne[19].getY()-80 && yBall-20 < brOne[19].getY()+60) && (xBall-20 > brOne[19].getX()-50 && xBall-20 < brOne[19].getX()+100) && brOne[19].GetFlag() == true) {
			
			if((xBall-20 > brOne[19].getX()+87 && xBall-20 < brOne[19].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[19].getX()-50 && xBall-20 < brOne[19].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[19].Erase(Color.TRANSPARENT);
			brOne[19].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 21
		if((yBall-20 > brOne[20].getY()-80 && yBall-20 < brOne[20].getY()+60) && (xBall-20 > brOne[20].getX()-50 && xBall-20 < brOne[20].getX()+100) && brOne[20].GetFlag() == true) {
			
			if((xBall-20 > brOne[20].getX()+87 && xBall-20 < brOne[20].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[20].getX()-50 && xBall-20 < brOne[20].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[20].Erase(Color.TRANSPARENT);
			brOne[20].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 22
		if((yBall-20 > brOne[21].getY()-80 && yBall-20 < brOne[21].getY()+60) && (xBall-20 > brOne[21].getX()-50 && xBall-20 < brOne[21].getX()+100) && brOne[21].GetFlag() == true) {
			
			if((xBall-20 > brOne[21].getX()+87 && xBall-20 < brOne[21].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[21].getX()-50 && xBall-20 < brOne[21].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[21].Erase(Color.TRANSPARENT);
			brOne[21].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 23
		if((yBall-20 > brOne[22].getY()-80 && yBall-20 < brOne[22].getY()+60) && (xBall-20 > brOne[22].getX()-50 && xBall-20 < brOne[22].getX()+100) && brOne[22].GetFlag() == true) {
			
			if((xBall-20 > brOne[22].getX()+87 && xBall-20 < brOne[22].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[22].getX()-50 && xBall-20 < brOne[22].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[22].Erase(Color.TRANSPARENT);
			brOne[22].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Ball 24
		if((yBall-20 > brOne[23].getY()-80 && yBall-20 < brOne[23].getY()+60) && (xBall-20 > brOne[23].getX()-50 && xBall-20 < brOne[23].getX()+100) && brOne[23].GetFlag() == true) {
			
			if((xBall-20 > brOne[23].getX()+87 && xBall-20 < brOne[23].getX()+100))
				xBallFlag = false;
			else if((xBall-20 > brOne[23].getX()-50 && xBall-20 < brOne[23].getX()-37))
				xBallFlag = true;
			else if((xBall-20 > brOne[0].getX()-50 && xBall-20 < brOne[0].getX()+100) && (yBall-20 > brOne[0].getY()+57 && yBall-20 < brOne[0].getY()+60)){
				yBallFlag = true;
			} else {
				yBallFlag = false;
			}
			
			vb.vibrate(30);
				
			brOne[23].Erase(Color.TRANSPARENT);
			brOne[23].NoBrick();
			scoreCount++;
			if(specialFlag == 0) {
				random = rand.nextInt(10) + 1;
				if(random == 1 || random == 2 || random == 3 || random == 4) {
					specialFlag = 1;
				}
			}
		}
		
		//Special Bricks
		if(random == 1 && specialFlag == 1) {
			specialFlag = 2;
			specialBrickSpeedY = yBall;
			specialBrickSpeedX = xBall;
			//specialBrick[0].Initialize(canvas, specialBrickSpeedX, specialBrickSpeedY);
		} else if(random == 2 && specialFlag == 1) {
			specialFlag = 2;
			specialBrickSpeedY = yBall;
			specialBrickSpeedX = xBall;
			//specialBrick[1].Initialize(canvas, specialBrickSpeedX, specialBrickSpeedY);
		} else if(random == 3 && specialFlag == 1) {
			specialFlag = 2;
			specialBrickSpeedY = yBall;
			specialBrickSpeedX = xBall;
			//specialBrick[2].Initialize(canvas, specialBrickSpeedX, specialBrickSpeedY);
		} else if(random == 4 && specialFlag == 1) {
			specialFlag = 2;
			specialBrickSpeedY = yBall;
			specialBrickSpeedX = xBall;
			//specialBrick[3].Initialize(canvas, specialBrickSpeedX, specialBrickSpeedY);
		}
		
		//Special Brick 
		if(specialFlag == 2) {
			specialBrick[random-1].Initialize(canvas, specialBrickSpeedX, specialBrickSpeedY);
			specialBrickSpeedY += 7;
			SpecialBrickCollision(canvas);
		}
		
		if(xBallFlag == true) {
			xBall -= ballSpeedX;
		}

		if(xBallFlag == false) {
			xBall += ballSpeedX;
		}
			
		if(yBallFlag == false)
			yBall += ballSpeedY;

		if(yBallFlag == true)
			yBall -= ballSpeedY;
		
		if(xBall < 20)
			xBallFlag = false;

		if(xBall > canvas.getWidth()-20)
			xBallFlag = true;
		
		if(yBall < 20)
			yBallFlag = false;

		if(yBall >= canvas.getHeight()) {
			yBallFlag = true;
			ballSpeedX=18;
			ballSpeedY = 12;
			playerHealth--;
		}
	}
	
	public void SpecialBrickCollision(Canvas canvas) {
		//Out Of Screen
		if(specialBrickSpeedY >= canvas.getHeight()+300) {
			specialFlag = 0;
			specialBrickSpeedY = 0;
		} else if((specialBrickSpeedX > player.getX()-100 && specialBrickSpeedX < player.getX()+playerSize) && (specialBrickSpeedY+50 > player.getY() && specialBrickSpeedY+50 < player.getY()+50)) {
		// Collision between Player and Special Brick	
			specialBrickSpeedX = 0;
			specialBrickSpeedY = 0;
			specialFlag = 0;
			
			if(random == 1) {
				playerSize -= 70;
			} else if (random == 2) {
				playerSize -= 70;
			} else if (random == 3) {
				playerSize += 70;
			} else if (random == 4) {
				playerSize += 70;
			}
			vb.vibrate(100);
		}
	}
	
}
